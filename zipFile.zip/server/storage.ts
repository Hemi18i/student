import { 
  students, 
  type Student, 
  type InsertStudent,
  transferRequests,
  type TransferRequest,
  type InsertTransferRequest,
  users,
  type User,
  type InsertUser
} from "@shared/schema";
import { db } from "./db";
import { eq, like, or, ilike } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Student methods
  getAllStudents(): Promise<Student[]>;
  getStudentById(id: number): Promise<Student | undefined>;
  getStudentByNationalId(nationalId: string): Promise<Student | undefined>;
  searchStudents(query: string, type: "nationalId" | "name"): Promise<Student[]>;
  createStudent(student: InsertStudent): Promise<Student>;
  updateStudent(id: number, data: Partial<InsertStudent>): Promise<Student | undefined>;
  deleteStudent(id: number): Promise<boolean>;
  bulkCreateStudents(students: InsertStudent[]): Promise<Student[]>;
  
  // Transfer request methods
  createTransferRequest(request: InsertTransferRequest): Promise<TransferRequest>;
  getTransferRequestsByStudentId(studentId: number): Promise<TransferRequest[]>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Student methods
  async getAllStudents(): Promise<Student[]> {
    return await db.select().from(students).orderBy(students.name);
  }

  async getStudentById(id: number): Promise<Student | undefined> {
    const [student] = await db.select().from(students).where(eq(students.id, id));
    return student || undefined;
  }

  async getStudentByNationalId(nationalId: string): Promise<Student | undefined> {
    const [student] = await db.select().from(students).where(eq(students.nationalId, nationalId));
    return student || undefined;
  }

  async searchStudents(query: string, type: "nationalId" | "name"): Promise<Student[]> {
    if (type === "nationalId") {
      return await db.select().from(students)
        .where(like(students.nationalId, `%${query}%`))
        .orderBy(students.name);
    } else {
      return await db.select().from(students)
        .where(ilike(students.name, `%${query}%`))
        .orderBy(students.name);
    }
  }

  async createStudent(student: InsertStudent): Promise<Student> {
    const [newStudent] = await db.insert(students).values(student).returning();
    return newStudent;
  }

  async updateStudent(id: number, data: Partial<InsertStudent>): Promise<Student | undefined> {
    const [updated] = await db.update(students)
      .set(data)
      .where(eq(students.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteStudent(id: number): Promise<boolean> {
    const result = await db.delete(students).where(eq(students.id, id));
    return true;
  }

  async bulkCreateStudents(studentsList: InsertStudent[]): Promise<Student[]> {
    if (studentsList.length === 0) return [];
    const result = await db.insert(students).values(studentsList).returning();
    return result;
  }

  // Transfer request methods
  async createTransferRequest(request: InsertTransferRequest): Promise<TransferRequest> {
    const [newRequest] = await db.insert(transferRequests).values(request).returning();
    return newRequest;
  }

  async getTransferRequestsByStudentId(studentId: number): Promise<TransferRequest[]> {
    return await db.select().from(transferRequests)
      .where(eq(transferRequests.studentId, studentId));
  }
}

export const storage = new DatabaseStorage();
