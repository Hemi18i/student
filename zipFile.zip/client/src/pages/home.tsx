import { useState, useEffect, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, Users, FileText, GraduationCap, X } from "lucide-react";
import { StudentList } from "@/components/student-list";
import { StudentDetails } from "@/components/student-details";
import { TransferRequestForm } from "@/components/transfer-request-form";
import { WarningForm } from "@/components/warning-form";
import { EnrollmentStatementForm } from "@/components/enrollment-statement-form";
import { EditStudentModal } from "@/components/edit-student-modal";
import type { Student } from "@shared/schema";

function useDebounce<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value);
  useEffect(() => {
    const timer = setTimeout(() => setDebouncedValue(value), delay);
    return () => clearTimeout(timer);
  }, [value, delay]);
  return debouncedValue;
}

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchType, setSearchType] = useState<"nationalId" | "name">("nationalId");
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [showTransferForm, setShowTransferForm] = useState(false);
  const [showWarningForm, setShowWarningForm] = useState(false);
  const [showEnrollmentForm, setShowEnrollmentForm] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);

  const debouncedSearchQuery = useDebounce(searchQuery, 300);

  const { data: students, isLoading: isLoadingStudents } = useQuery<Student[]>({
    queryKey: ["/api/students"],
  });

  const { data: searchResults, isLoading: isSearching } = useQuery<Student[]>({
    queryKey: ["/api/students/search", debouncedSearchQuery, searchType],
    queryFn: async () => {
      const response = await fetch(`/api/students/search?q=${encodeURIComponent(debouncedSearchQuery)}&type=${searchType}`);
      if (!response.ok) throw new Error("Search failed");
      return response.json();
    },
    enabled: debouncedSearchQuery.length > 0,
  });

  const displayStudents = debouncedSearchQuery.length > 0 ? searchResults : students;
  const totalStudents = students?.length || 0;

  const handleSelectStudent = (student: Student) => {
    setSelectedStudent(student);
    setShowTransferForm(false);
    setShowWarningForm(false);
    setShowEnrollmentForm(false);
  };

  const handleTransferRequest = () => {
    if (selectedStudent) {
      setShowTransferForm(true);
      setShowWarningForm(false);
      setShowEnrollmentForm(false);
    }
  };

  const handleWarning = () => {
    if (selectedStudent) {
      setShowWarningForm(true);
      setShowTransferForm(false);
      setShowEnrollmentForm(false);
    }
  };

  const handleEnrollmentStatement = () => {
    if (selectedStudent) {
      setShowEnrollmentForm(true);
      setShowTransferForm(false);
      setShowWarningForm(false);
    }
  };

  const handleEditStudent = () => {
    if (selectedStudent) {
      setShowEditModal(true);
    }
  };

  const clearSearch = () => {
    setSearchQuery("");
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-card border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3 flex-wrap">
              <div className="p-2 bg-primary rounded-lg">
                <GraduationCap className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-xl sm:text-2xl font-bold text-foreground" data-testid="text-app-title">
                  نظام إدارة بيانات الطلاب
                </h1>
                <p className="text-sm text-muted-foreground" data-testid="text-school-name">
                  السعرانية الثانوية المشتركة
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <Badge variant="secondary" className="gap-1" data-testid="badge-student-count">
                <Users className="h-3 w-3" />
                <span>{totalStudents} طالب</span>
              </Badge>
            </div>
          </div>
        </div>
      </header>

      {/* Search Section */}
      <div className="sticky top-[73px] z-40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="flex gap-2">
              <Button
                variant={searchType === "nationalId" ? "default" : "outline"}
                size="sm"
                onClick={() => setSearchType("nationalId")}
                data-testid="button-search-national-id"
              >
                بالرقم القومي
              </Button>
              <Button
                variant={searchType === "name" ? "default" : "outline"}
                size="sm"
                onClick={() => setSearchType("name")}
                data-testid="button-search-name"
              >
                بالاسم
              </Button>
            </div>
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder={searchType === "nationalId" ? "ابحث بالرقم القومي..." : "ابحث بالاسم..."}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-10 pl-10"
                data-testid="input-search"
              />
              {searchQuery && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute left-1 top-1/2 -translate-y-1/2 h-7 w-7"
                  onClick={clearSearch}
                  data-testid="button-clear-search"
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Student List */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  قائمة الطلاب
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                {isLoadingStudents || isSearching ? (
                  <div className="p-4 space-y-3">
                    {[...Array(5)].map((_, i) => (
                      <Skeleton key={i} className="h-16 w-full" />
                    ))}
                  </div>
                ) : (
                  <StudentList
                    students={displayStudents || []}
                    selectedStudent={selectedStudent}
                    onSelectStudent={handleSelectStudent}
                  />
                )}
              </CardContent>
            </Card>
          </div>

          {/* Student Details / Forms */}
          <div className="lg:col-span-2">
            {showTransferForm && selectedStudent ? (
              <TransferRequestForm
                student={selectedStudent}
                onClose={() => setShowTransferForm(false)}
              />
            ) : showWarningForm && selectedStudent ? (
              <WarningForm
                student={selectedStudent}
                onClose={() => setShowWarningForm(false)}
              />
            ) : showEnrollmentForm && selectedStudent ? (
              <EnrollmentStatementForm
                student={selectedStudent}
                onClose={() => setShowEnrollmentForm(false)}
              />
            ) : selectedStudent ? (
              <StudentDetails
                student={selectedStudent}
                onTransferRequest={handleTransferRequest}
                onEdit={handleEditStudent}
                onWarning={handleWarning}
                onEnrollmentStatement={handleEnrollmentStatement}
              />
            ) : (
              <Card className="h-full min-h-[400px] flex items-center justify-center">
                <CardContent className="text-center py-12">
                  <div className="p-4 bg-muted rounded-full w-fit mx-auto mb-4">
                    <FileText className="h-8 w-8 text-muted-foreground" />
                  </div>
                  <h3 className="text-lg font-medium text-foreground mb-2">
                    اختر طالباً لعرض بياناته
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    يمكنك البحث بالرقم القومي أو الاسم للعثور على الطالب المطلوب
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>

      {/* Edit Student Modal */}
      {showEditModal && selectedStudent && (
        <EditStudentModal
          student={selectedStudent}
          open={showEditModal}
          onClose={() => setShowEditModal(false)}
          onSave={(updatedStudent) => {
            setSelectedStudent(updatedStudent);
            setShowEditModal(false);
          }}
        />
      )}
    </div>
  );
}
