import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { User } from "lucide-react";
import type { Student } from "@shared/schema";

interface StudentListProps {
  students: Student[];
  selectedStudent: Student | null;
  onSelectStudent: (student: Student) => void;
}

export function StudentList({ students, selectedStudent, onSelectStudent }: StudentListProps) {
  if (students.length === 0) {
    return (
      <div className="p-8 text-center">
        <div className="p-3 bg-muted rounded-full w-fit mx-auto mb-3">
          <User className="h-6 w-6 text-muted-foreground" />
        </div>
        <p className="text-sm text-muted-foreground">لا يوجد طلاب</p>
      </div>
    );
  }

  return (
    <ScrollArea className="h-[calc(100vh-350px)] min-h-[300px]">
      <div className="divide-y divide-border">
        {students.map((student) => (
          <button
            key={student.id}
            onClick={() => onSelectStudent(student)}
            className={`w-full text-right p-4 transition-colors hover-elevate active-elevate-2 ${
              selectedStudent?.id === student.id
                ? "bg-accent"
                : ""
            }`}
            data-testid={`student-row-${student.id}`}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1 min-w-0">
                <p className="font-medium text-foreground truncate mb-1">
                  {student.name}
                </p>
                <p className="text-xs text-muted-foreground font-mono" dir="ltr">
                  {student.nationalId}
                </p>
              </div>
              <div className="flex flex-col items-end gap-1">
                <Badge variant="secondary" className="text-xs">
                  {student.classRoom || "غير محدد"}
                </Badge>
                <span className="text-xs text-muted-foreground">
                  {student.gender === "أنثى" ? "طالبة" : "طالب"}
                </span>
              </div>
            </div>
          </button>
        ))}
      </div>
    </ScrollArea>
  );
}
